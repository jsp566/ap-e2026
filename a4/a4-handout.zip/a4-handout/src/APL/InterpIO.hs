module APL.InterpIO (runEvalIO) where

import APL.Monad
import APL.Util
import System.Directory (removeFile)
import System.IO (hFlush, readFile', stdout)

-- Converts a string into a value. Only 'ValInt's and 'ValBool' are supported.
readVal :: String -> Maybe Val
readVal = unserialize

-- 'prompt s' prints 's' to the console and then reads a line from stdin.
prompt :: String -> IO String
prompt s = do
  putStr s
  hFlush stdout
  getLine

-- 'writeDB dbFile s' writes the 'State' 's' to the file 'db'.
writeDB :: FilePath -> State -> IO ()
writeDB db s =
  writeFile db $ serialize s

-- 'readDB db' reads the database stored in 'db'.
readDB :: FilePath -> IO (Either Error State)
readDB db = do
  ms <- readFile' db
  case unserialize ms of
    Just s -> pure $ pure s
    Nothing -> pure $ Left "Invalid DB."

-- 'copyDB db1 db2' copies 'db1' to 'db2'.
copyDB :: FilePath -> FilePath -> IO ()
copyDB db db' = do
  s <- readFile' db
  writeFile db' s

-- Removes all key-value pairs from the database file.
clearDB :: IO ()
clearDB = writeFile dbFile ""

-- The name of the database file.
dbFile :: FilePath
dbFile = "db.txt"

-- Creates a fresh temporary database, passes it to a function returning an
-- IO-computation, executes the computation, deletes the temporary database, and
-- finally returns the result of the computation. The temporary database file is
-- guaranteed fresh and won't have a name conflict with any other files.
withTempDB :: (FilePath -> IO a) -> IO a
withTempDB m = do
  tempDB <- newTempDB -- Create a new temp database file.
  res <- m tempDB -- Run the computation with the new file.
  removeFile tempDB -- Delete the temp database file.
  pure res -- Return the result of the computation.

runEvalIO :: EvalM a -> IO (Either Error a)
runEvalIO evalm = do
  clearDB
  result <- runEvalIO' envEmpty dbFile evalm
  pure $ case result of
    Left _ -> Left "Break outside loop"
    Right res -> res
  where
    runEvalIO' :: Env -> FilePath -> EvalM a -> IO (Either Val (Either Error a))
    runEvalIO' _ _ (Pure x) = pure $ pure (pure x)
    runEvalIO' r db (Free (ReadOp k)) = runEvalIO' r db $ k r
    runEvalIO' r db (Free (PrintOp p m)) = do
      putStrLn p
      runEvalIO' r db m
    runEvalIO' _ _ (Free (ErrorOp e)) = pure $ Right (Left e)
    runEvalIO' r db (Free (TryCatchOp m1 m2 k)) = do
      res <- runEvalIO' r db m1
      case res of
        Left val -> pure $ Left val
        Right (Left _) -> runEvalIO' r db (m2 >>= k)
        Right (Right val) -> runEvalIO' r db (k val)
    runEvalIO' r db (Free (KvGetOp key k)) = do
      Right st <- readDB db
      case lookup key st of
        Just val -> runEvalIO' r db $ k val
        Nothing -> do
          s <- prompt ("Invalid key: " ++ show key ++ ". Enter a replacement: ")
          case readVal s of
            Just newval -> runEvalIO' r db $ k newval
            Nothing -> pure $ Right (Left ("Invalid value input: " ++ s))
    runEvalIO' r db (Free (KvPutOp key val m)) = do
      Right s <- readDB db
      writeDB db ((key, val) : s)
      runEvalIO' r db m
    runEvalIO' r db (Free (TransactionOp m k)) =
      withTempDB $ \temp -> do
        copyDB db temp
        result <- runEvalIO' r temp m
        case result of
          Right (Right val) -> do
            copyDB temp db
            runEvalIO' r db (k val)
          Right (Left err) -> pure $ Right (Left err)
          Left val -> do
            copyDB temp db
            pure $ Left val
    runEvalIO' r db (Free (LoopingOp m k)) = do
      result <- runEvalIO' r db m
      case result of
        Right (Left err) -> pure $ Right (Left err)
        Right (Right val) -> runEvalIO' r db (k val)
        Left val -> runEvalIO' r db (k val)
    runEvalIO' _ _ (Free (BreakLoopOp val _)) =
      pure $ Left val